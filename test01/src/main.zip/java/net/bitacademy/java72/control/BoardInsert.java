package net.bitacademy.java72.control;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.springframework.context.ApplicationContext;

import net.bitacademy.java72.dao.BoardDao;
import net.bitacademy.java72.domain.Board;

public class BoardInsert extends HttpServlet {
  private static final long serialVersionUID = 1L;

  class FileInfo {
    String originName;
    String realFilePath;
    
    public FileInfo(String originName, String realFilePath) {
      this.originName = originName;
      this.realFilePath = realFilePath;
    }
  }  
  
  @Override
  protected void doPost(
      HttpServletRequest request, 
      HttpServletResponse response) throws ServletException, IOException {
    
    DiskFileItemFactory itemFactory = new DiskFileItemFactory();
    
    ServletFileUpload upload = new ServletFileUpload(itemFactory);
    
    List<FileItem> items;
    HashMap<String, Object> paramMap = new HashMap<String, Object>();
    try {
      items = upload.parseRequest(request);

      for (FileItem item : items) {
        if (item.isFormField()) {
          paramMap.put(item.getFieldName(), item.getString("UTF-8"));
        } else {
          ServletContext context = request.getServletContext();
          String realPath = context.getRealPath("/files");
          File filePath = new File(realPath + "/" + item.getName());
          item.write(filePath);

          paramMap.put(item.getFieldName(),
              new FileInfo(item.getName(), filePath.getAbsolutePath()));
        }
      }
    } catch (Exception e) {
      e.printStackTrace();
    }
    
    ApplicationContext context = 
        (ApplicationContext)this.getServletContext()
           .getAttribute("beanContainer");
    
    BoardDao boardDao = (BoardDao)context.getBean("boardDao");
      
    Board board = new Board(); 
    board.setTitle((String) paramMap.get("title"));
    board.setContent((String) paramMap.get("content"));
    board.setPassword((String) paramMap.get("password"));
    FileInfo fileInfo = (FileInfo) paramMap.get("attachFile1");
    board.setAttachFile1(fileInfo.originName);
    
    try {
      boardDao.insert(board);
    } catch (Exception e) {
      RequestDispatcher rd = 
          request.getRequestDispatcher("/error");

      //ServletRequest에 전달할 객체를 저장한다.
      request.setAttribute("error", e);
      
      rd.forward(request, response);
      return;
    }
    response.sendRedirect("list.do");
  }

}






