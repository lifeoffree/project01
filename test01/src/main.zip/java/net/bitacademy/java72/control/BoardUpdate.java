package net.bitacademy.java72.control;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.bitacademy.java72.dao.BoardDao;
import net.bitacademy.java72.domain.Board;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.springframework.context.ApplicationContext;

public class BoardUpdate extends HttpServlet {
  private static final long serialVersionUID = 1L;

  class FileInfo {
    String originName;
    String realFilePath;

    public FileInfo(String originName, String realFilePath) {
      this.originName = originName;
      this.realFilePath = realFilePath;
    }

    @Override
    public String toString() {
      return "FileInfo [originName=" + originName + ", realFilePath="
          + realFilePath + "]";
    }


  }

  @Override
  protected void doPost(HttpServletRequest request, HttpServletResponse response)
      throws ServletException, IOException {

    DiskFileItemFactory itemFactory = new DiskFileItemFactory();

    ServletFileUpload upload = new ServletFileUpload(itemFactory);

    HashMap<String, Object> paramMap = new HashMap<String, Object>();

    try {
      List<FileItem> items = upload.parseRequest(request);

      // 4) FileItem을 분석하여 name 값과 photo 값을 꺼낸다.
      for (FileItem item : items) {
        if (item.isFormField()) {
          paramMap.put(item.getFieldName(), item.getString("UTF-8")); // request.setCharacterEncoding()
                                                                      // 효력 없음
        } else {
          ServletContext context = request.getServletContext();
          String realPath = context.getRealPath("/files");
          File filePath = new File(realPath + "/" + item.getName());

          System.out.println("filePath-->"+filePath);
          System.out.println("fileFieldName-->"+item.getFieldName());
          System.out.println("fileName-->"+item.getName());
          
          item.write(filePath);

          
          paramMap.put(item.getFieldName(), new FileInfo(item.getName(),
              filePath.getAbsolutePath()));
        }
      }
    } catch (Exception e1) {
      e1.printStackTrace();
    }
    ApplicationContext context =

    (ApplicationContext) this.getServletContext().getAttribute("beanContainer");

    BoardDao boardDao = (BoardDao) context.getBean("boardDao");

    int no = Integer.parseInt((String) paramMap.get("no"));

    Board board = boardDao.get(no);
    board.setNo(no);
    board.setTitle((String) paramMap.get("title"));
    board.setContent((String) paramMap.get("content"));
    board.setPassword((String) paramMap.get("password"));
    FileInfo fileInfo = (FileInfo) paramMap.get("attachFile1");
    
    if (fileInfo != null) {
      board.setAttachFile1(fileInfo.originName);
      System.out.println(fileInfo);
      System.out.println("fileInfo.originName===>"+fileInfo.originName);
      
    }
    
    
    try {
      boardDao.update(board);
    } catch (Exception e) {
      RequestDispatcher rd = request.getRequestDispatcher("/error");
      rd.forward(request, response);
      request.setAttribute("error", e);
      return;
    }
    response.sendRedirect("list.do");
  }

}